import { test, expect } from '@playwright/test'
import { LoginPage } from '../pages/loginPage'
import { DashboardPage } from '../pages/dashboardPage'
import { CartPage } from '../pages/cartPage'
import { PaymentPage } from '../pages/paymentPage'
import product from '../testdata/product.json'
import payment from '../testdata/payment.json'

const checkoutProduct = product[0]

test.describe('Payment page', () => {
    let lp: LoginPage
    let dp: DashboardPage
    let cp: CartPage
    let pp: PaymentPage

    test.beforeEach(async ({ page }) => {
        lp = new LoginPage(page)
        dp = new DashboardPage(page)
        cp = new CartPage(page)
        pp = new PaymentPage(page)
        await lp.launchUrl(checkoutProduct.url)
        await lp.loginIntoApplication(checkoutProduct.email, checkoutProduct.password)
        await dp.searchAndAddProduct(checkoutProduct.productName, 1)
        await dp.navigateToCart()
        await cp.verifyCartPage()
        await cp.proceedToCheckout()
    })

    test('places an order with valid payment details', async () => {
        await pp.enterPaymentDetails(payment)
        await pp.placeOrder()
        await expect(pp.orderConfirmation).toBeVisible()
        await expect(pp.orderNumber).toBeVisible()
    })

    test('shows validation when payment details are missing', async () => {
        await pp.placeOrder()
        await expect(pp.paymentErrorMessage.first()).toBeVisible()
    })

    test('shows validation for an invalid card number and CVV', async () => {
        await pp.enterPaymentDetails({
            ...payment,
            cardNumber: payment.invalidCardNumber,
            cvv: payment.invalidCvv
        })
        await pp.placeOrder()
        await expect(pp.paymentErrorMessage.first()).toBeVisible()
    })
})