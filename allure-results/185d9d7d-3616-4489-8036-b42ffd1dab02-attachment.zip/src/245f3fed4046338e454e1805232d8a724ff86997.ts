import { Locator, Page } from "@playwright/test";

export class PaymentPage {
    page: Page
    nameOnCard: Locator
    cardNumber: Locator
    expiryDate: Locator
    cvv: Locator
    country: Locator
    placeOrderButton: Locator
    paymentErrorMessage: Locator
    orderConfirmation: Locator
    orderNumber: Locator

    constructor(page: Page) {
        this.page = page
        this.nameOnCard = this.page.locator('input[placeholder="Name on Card"]')
        this.cardNumber = this.page.locator('input[placeholder="Credit Card Number"]')
        this.expiryDate = this.page.locator('input[placeholder="MM/YY"]')
        this.cvv = this.page.locator('input[placeholder="CVV"]')
        this.country = this.page.locator('input[placeholder="Select Country"]')
        this.placeOrderButton = this.page.getByRole('button', { name: /place order/i })
        this.paymentErrorMessage = this.page.locator('.invalid-feedback, #toast-container')
        this.orderConfirmation = this.page.getByText(/thank you for shopping with us/i)
        this.orderNumber = this.page.locator('.em-spacer-1 .ng-star-inserted')
    }

    async enterPaymentDetails(paymentData: {
        nameOnCard: string
        cardNumber: string
        expiryDate: string
        cvv: string
        country: string
    }) {
        await this.nameOnCard.fill(paymentData.nameOnCard)
        await this.cardNumber.fill(paymentData.cardNumber)
        await this.expiryDate.fill(paymentData.expiryDate)
        await this.cvv.fill(paymentData.cvv)
        await this.country.fill(paymentData.country)
        await this.page.getByRole('button', { name: new RegExp(`^${paymentData.country}$`, 'i') }).click()
    }

    async placeOrder() {
        await this.placeOrderButton.click()
    }
}