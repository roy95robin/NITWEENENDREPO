import { Locator, Page } from "@playwright/test";

export class CartPage {
    page: Page
    cartItems: Locator
    productNames: Locator
    productPrices: Locator
    deleteButtons: Locator
    checkoutButton: Locator
    emptyCartMessage: Locator

    constructor(page: Page) {
        this.page = page
        this.cartItems = this.page.locator('.cartSection')
        this.productNames = this.page.locator('.cartSection h3')
        this.productPrices = this.page.locator('.cartSection .prodTotal p')
        this.deleteButtons = this.page.locator('.cartSection button')
        this.checkoutButton = this.page.getByRole('button', { name: /checkout/i })
        this.emptyCartMessage = this.page.getByText(/your cart is empty|no products in the cart/i)
    }

    async verifyCartPage() {
        await this.cartItems.first().waitFor()
    }

    async removeProduct(productName: string) {
        const item = this.cartItems.filter({ hasText: productName })
        await item.locator('button').click()
    }

    async proceedToCheckout() {
        await this.checkoutButton.click()
    }
}