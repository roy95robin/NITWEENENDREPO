import { Locator, Page } from "@playwright/test";

export class PaymentPage {
    page: Page
    placeOrderButton: Locator
    orderConfirmation: Locator

    constructor(page: Page) {
        this.page = page
        this.placeOrderButton = this.page.getByRole('button', { name: /place order/i })
        this.orderConfirmation = this.page.getByText(/thank you for shopping with us/i)
    }

    async completePayment(paymentData: {
        nameOnCard: string
        cardNumber: string
        expiryMonth: string
        expiryYear: string
        cvv: string
        country: string
    }) {
        await this.page.getByText('Credit Card Number', { exact: true }).locator('..').locator('input').fill(paymentData.cardNumber)
        await this.page.getByRole('combobox').nth(0).selectOption(paymentData.expiryMonth)
        await this.page.getByRole('combobox').nth(1).selectOption(paymentData.expiryYear)
        await this.page.getByText('CVV Code ?', { exact: true }).locator('..').locator('input').fill(paymentData.cvv)
        await this.page.getByText('Name on Card', { exact: true }).locator('..').locator('input').fill(paymentData.nameOnCard)
        const country = this.page.locator('input[placeholder="Select Country"]')
        await country.fill(paymentData.country)
        await this.placeOrder()
    }

    async placeOrder() {
        await this.placeOrderButton.click()
    }
}