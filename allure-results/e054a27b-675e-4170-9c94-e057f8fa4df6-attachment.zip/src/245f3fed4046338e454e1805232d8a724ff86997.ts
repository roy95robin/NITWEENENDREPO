import { Locator, Page } from "@playwright/test";

export class PaymentPage {
    page: Page
    placeOrderButton: Locator
    orderConfirmation: Locator

    constructor(page: Page) {
        this.page = page
        this.placeOrderButton = this.page.getByRole('button', { name: /place order/i })
        this.orderConfirmation = this.page.getByText(/thank you for shopping with us/i)
    }

    async completePayment(paymentData: {
        nameOnCard: string
        cardNumber: string
        expiryDate: string
        cvv: string
        country: string
    }) {
        await this.page.locator('input[placeholder="Name on Card"]').fill(paymentData.nameOnCard)
        await this.page.locator('input[placeholder="Credit Card Number"]').fill(paymentData.cardNumber)
        await this.page.locator('input[placeholder="MM/YY"]').fill(paymentData.expiryDate)
        await this.page.locator('input[placeholder="CVV"]').fill(paymentData.cvv)
        const country = this.page.locator('input[placeholder="Select Country"]')
        await country.fill(paymentData.country)
        await this.page.getByRole('button', { name: new RegExp(`^${paymentData.country}$`, 'i') }).click()
        await this.placeOrder()
    }

    async placeOrder() {
        await this.placeOrderButton.click()
    }
}